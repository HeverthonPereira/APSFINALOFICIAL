package cadastroMedicamento;

import apresentacao.principal;

public class CadastroMedicamento {
    public static void main(String[] args) {
        principal principal = new principal();
        principal.setVisible(true);
    }
}
